from ultralytics import YOLO
import cv2
import cvzone
import math


cap= cv2.VideoCapture("test-1.avi") #from video 1

model = YOLO("best_weights.pt")

class_names = ["insan" , "Tasit" , "UAI" , "UAP" , "unsafe_UAI" , "unsafe_UAP"]

box_color = ()

myColor= (0 , 0 , 255)

frame_width = int(cap.get(3))
frame_height = int(cap.get(4))
size = (frame_width , frame_height)

result = cv2.VideoWriter("result-video.avi" , cv2.VideoWriter_fourcc(*'MJPG'), 10 , size)
myList = [""]

while True:
    success , img = cap.read()
    results = model(img , device = '0') # using GPU

    for r  in results:
        boxes = r.boxes
        for box in boxes:
        # Bounding Box
         x1 , y1 , x2 , y2 = box.xyxy[0]
         x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)

         w , h = x2 - x1 , y2 -y1
        #cvzone.cornerRect(img , ( x1 , y1 , w , h ))
        cv2.rectangle(img , (x1 , y1) , ( x2 , y2) , myColor , 3 )
        #Confidence
        conf = math.ceil(box.conf[0] * 100))/100
        #class name
        cls = int(box.cls[0])
        currentClass = class_names[cls]

        if conf > 0.3:
            if currentClass == 'unsafe_UAI' or currentClass ="unsafe_UAP":
               myColor  = (0 , 255 , 0 )
            else:
                myColor = (255 , 0 , 0 )

        cvzone.putTextRect(img , f'{class_names[cls]} {conf}',
        ( max(0 , x1) , max(35,y1)) , scale = 1.0 ,
        thickness = 1 , color8 = myColor ,
        colorT = (255 , 255 , 255 ) , colorR = myColor , offset = 5)

        result.write(img)

    cv2.imshow("Image", img)
    cv2.waitKey(1)

print("myList is \n" , myList)

cap.release()
cv2.destroyAllWindows()
